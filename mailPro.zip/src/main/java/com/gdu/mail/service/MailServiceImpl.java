package com.gdu.mail.service;

import org.springframework.stereotype.Service;

@Service
public class MailServiceImpl implements MailService {
	
}
