package com.gdu.mail.service;

public interface MailService {

}
